'''
# Welcome to your CDK TypeScript Construct Library project!

You should explore the contents of this project. It demonstrates a CDK Construct Library that includes a construct (`MultiRegionS3CrrKmsCmkTarget`)
which contains an Amazon SQS queue that is subscribed to an Amazon SNS topic.

The construct defines an interface (`MultiRegionS3CrrKmsCmkTargetProps`) to configure the visibility timeout of the queue.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
'''
import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from ._jsii import *

import aws_cdk.aws_s3
import aws_cdk.core


class MultiRegionS3CrrKmsCmkTarget(
    aws_cdk.core.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="multi-region-s3-crr-kms-cmk-target.MultiRegionS3CrrKmsCmkTarget",
):
    def __init__(self, scope: aws_cdk.core.Construct, id: builtins.str) -> None:
        '''
        :param scope: -
        :param id: -
        '''
        jsii.create(MultiRegionS3CrrKmsCmkTarget, self, [scope, id])

    @builtins.property # type: ignore[misc]
    @jsii.member(jsii_name="targetBucket")
    def target_bucket(self) -> aws_cdk.aws_s3.Bucket:
        return typing.cast(aws_cdk.aws_s3.Bucket, jsii.get(self, "targetBucket"))

    @builtins.property # type: ignore[misc]
    @jsii.member(jsii_name="targetKeyIdSsmParameterName")
    def target_key_id_ssm_parameter_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "targetKeyIdSsmParameterName"))


__all__ = [
    "MultiRegionS3CrrKmsCmkTarget",
]

publication.publish()
