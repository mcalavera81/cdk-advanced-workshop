'''
# Welcome to your CDK TypeScript Construct Library project!

You should explore the contents of this project. It demonstrates a CDK Construct Library that includes a construct (`MultiRegionS3CrrKmsCmkSource`)
which contains an Amazon SQS queue that is subscribed to an Amazon SNS topic.

The construct defines an interface (`MultiRegionS3CrrKmsCmkSourceProps`) to configure the visibility timeout of the queue.

## Useful commands

* `npm run build`   compile typescript to js
* `npm run watch`   watch for changes and compile
* `npm run test`    perform the jest unit tests
'''
import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from ._jsii import *

import aws_cdk.aws_s3
import aws_cdk.core


class MultiRegionS3CrrKmsCmkSource(
    aws_cdk.core.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="multi-region-s3-crr-kms-cmk-source.MultiRegionS3CrrKmsCmkSource",
):
    def __init__(
        self,
        scope: aws_cdk.core.Construct,
        id: builtins.str,
        *,
        target_bucket: aws_cdk.aws_s3.Bucket,
        target_key_id_ssm_parameter_name: builtins.str,
        target_region: builtins.str,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param target_bucket: -
        :param target_key_id_ssm_parameter_name: -
        :param target_region: -
        '''
        props = MultiRegionS3CrrKmsCmkSourceProps(
            target_bucket=target_bucket,
            target_key_id_ssm_parameter_name=target_key_id_ssm_parameter_name,
            target_region=target_region,
        )

        jsii.create(MultiRegionS3CrrKmsCmkSource, self, [scope, id, props])


@jsii.data_type(
    jsii_type="multi-region-s3-crr-kms-cmk-source.MultiRegionS3CrrKmsCmkSourceProps",
    jsii_struct_bases=[],
    name_mapping={
        "target_bucket": "targetBucket",
        "target_key_id_ssm_parameter_name": "targetKeyIdSsmParameterName",
        "target_region": "targetRegion",
    },
)
class MultiRegionS3CrrKmsCmkSourceProps:
    def __init__(
        self,
        *,
        target_bucket: aws_cdk.aws_s3.Bucket,
        target_key_id_ssm_parameter_name: builtins.str,
        target_region: builtins.str,
    ) -> None:
        '''
        :param target_bucket: -
        :param target_key_id_ssm_parameter_name: -
        :param target_region: -
        '''
        self._values: typing.Dict[str, typing.Any] = {
            "target_bucket": target_bucket,
            "target_key_id_ssm_parameter_name": target_key_id_ssm_parameter_name,
            "target_region": target_region,
        }

    @builtins.property
    def target_bucket(self) -> aws_cdk.aws_s3.Bucket:
        result = self._values.get("target_bucket")
        assert result is not None, "Required property 'target_bucket' is missing"
        return typing.cast(aws_cdk.aws_s3.Bucket, result)

    @builtins.property
    def target_key_id_ssm_parameter_name(self) -> builtins.str:
        result = self._values.get("target_key_id_ssm_parameter_name")
        assert result is not None, "Required property 'target_key_id_ssm_parameter_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def target_region(self) -> builtins.str:
        result = self._values.get("target_region")
        assert result is not None, "Required property 'target_region' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "MultiRegionS3CrrKmsCmkSourceProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "MultiRegionS3CrrKmsCmkSource",
    "MultiRegionS3CrrKmsCmkSourceProps",
]

publication.publish()
